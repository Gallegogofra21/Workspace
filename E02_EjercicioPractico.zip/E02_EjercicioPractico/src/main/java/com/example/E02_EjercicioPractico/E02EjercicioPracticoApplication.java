package com.example.E02_EjercicioPractico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E02EjercicioPracticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(E02EjercicioPracticoApplication.class, args);
	}

}
