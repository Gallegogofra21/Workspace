package com.example.E02_EjercicioPractico;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/monumento")
@RequiredArgsConstructor
public class MonumentoController {

    private final MonumentoRepository repository;

    @GetMapping("/")
    public List<Monumento> findAll() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Monumento findOne(@PathVariable("id") Long id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping("/")
    public ResponseEntity<Monumento> create(@RequestBody Monumento monumento) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(repository.save(monumento));
    }

    @PutMapping("/{id}")
    public Monumento edit(@RequestBody Monumento monumento, @PathVariable Long id) {

        Monumento antiguo = repository.findById(id).orElse(monumento);
        antiguo.setCodigoPais(monumento.getCodigoPais());
        antiguo.setNombrePais(monumento.getNombrePais());
        antiguo.setNombreCiudad(monumento.getNombreCiudad());
        antiguo.setLatitud(monumento.getLatitud());
        antiguo.setLongitud(monumento.getLongitud());
        antiguo.setNombreMonumento(monumento.getNombreMonumento());
        antiguo.setDescripcion(monumento.getDescripcion());
        antiguo.setUrlFoto(monumento.getUrlFoto());

        return repository.save(antiguo);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") Long id) {
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }


}
